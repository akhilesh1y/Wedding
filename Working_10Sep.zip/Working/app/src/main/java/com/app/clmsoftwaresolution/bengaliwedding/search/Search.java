package com.app.clmsoftwaresolution.bengaliwedding.search;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.clmsoftwaresolution.bengaliwedding.R;
import com.app.clmsoftwaresolution.bengaliwedding.adapters.SelectionAdapter;
import com.app.clmsoftwaresolution.bengaliwedding.listeners.SelectionListener;
import com.app.clmsoftwaresolution.bengaliwedding.model.SelectionModel;

import java.util.ArrayList;

public class Search extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = Search.class.getName();
    private Context mContext;
    private TextView tvAge;
    private TextView tvHeight;
    private TextView tvCaste;
    private TextView tvMotherToungue;
    private TextView tvRelogion;
    private TextView tvCity;
    private TextView tvState;
    private TextView tvCountry;

    private RelativeLayout rlAge;
    private RelativeLayout rlCaste;
    private RelativeLayout rlHeight;
    private RelativeLayout rlMotherToungue;
    private RelativeLayout rlReligion;
    private RelativeLayout rlCity;
    private RelativeLayout rlState;
    private RelativeLayout rlCountry;
    private TextView tvAdvanceSearch;
    private LinearLayout llAdvanceSarch;
    private RelativeLayout rlProfession;
    private RelativeLayout rlPhysical;
    private RelativeLayout rlLifestyle;
    private RelativeLayout rlAstrology;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ui();
    }

    private void ui(){

        initContext();
        initViews();
        clickListener();
    }

    private void initContext(){
        mContext = this;
    }

    private void initViews(){
        tvAge = findViewById(R.id.item_age);
        tvHeight = findViewById(R.id.item_height);
        tvCaste = findViewById(R.id.item_cast);
        tvMotherToungue = findViewById(R.id.item_mother_language);
        tvRelogion = findViewById(R.id.item_religion);
        tvCity = findViewById(R.id.tv_item_city);
        tvState = findViewById(R.id.tv_state);
        tvCountry = findViewById(R.id.tv_country);


        rlAge = findViewById(R.id.rl_age);
        rlHeight = findViewById(R.id.rl_height);
        rlCaste = findViewById(R.id.rl_cast);
        rlMotherToungue = findViewById(R.id.rl_mother_toungue);
        rlReligion = findViewById(R.id.rl_religion);
        rlCity = findViewById(R.id.rl_city);
        rlState = findViewById(R.id.rl_state);
        rlCountry = findViewById(R.id.rl_country);

        tvAdvanceSearch = findViewById(R.id.tv_advance_search);
        llAdvanceSarch = findViewById(R.id.ll_advance_search);
        rlProfession = findViewById(R.id.rl_physical);
        rlPhysical = findViewById(R.id.rl_profession);
        rlLifestyle = findViewById(R.id.rl_lifestyle);
        rlAstrology = findViewById(R.id.rl_astrology);
    }

    private void clickListener(){
        rlAge.setOnClickListener(this);
        rlHeight.setOnClickListener(this);
        rlCaste.setOnClickListener(this);
        rlMotherToungue.setOnClickListener(this);
        rlReligion.setOnClickListener(this);
        rlCity.setOnClickListener(this);
        rlState.setOnClickListener(this);
        rlCountry.setOnClickListener(this);

        tvAdvanceSearch.setOnClickListener(this);
        rlProfession.setOnClickListener(this);
        rlPhysical.setOnClickListener(this);
        rlLifestyle.setOnClickListener(this);
        rlAstrology.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

            case R.id.rl_age:
                showAgeSelectionDialog();
                break;
            case R.id.rl_height:
                showHeightSelectionDialog();
                break;
            case R.id.rl_cast:
                showCasteSelectionDialog("Caste");
                break;
            case R.id.rl_mother_toungue:
                showCasteSelectionDialog("Language");
                break;
            case R.id.rl_religion:
                showCasteSelectionDialog("Religion");
                break;
            case R.id.rl_city:
                showCasteSelectionDialog("City");
                break;
            case R.id.rl_state:
                showCasteSelectionDialog("State");
                break;
            case R.id.rl_country:
                showCasteSelectionDialog("Country");
                break;
            case R.id.tv_advance_search:
                llAdvanceSarch.setVisibility(View.VISIBLE);
                break;
            case R.id.rl_profession:
                showAdvanceSearchOptions("Profession");
                break;
            case R.id.rl_physical:
                showAdvanceSearchOptions("Physical");
                break;
            case R.id.rl_lifestyle:
                showAdvanceSearchOptions("Lifestyle");
                break;
            case R.id.rl_astrology:
                showAdvanceSearchOptions("Astrology");
                break;
                default:
                    break;
        }
    }

    private void showAgeSelectionDialog(){
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_age_select);
        dialog.setCancelable(true);
        dialog.show();

        final ImageView ivOk = dialog.findViewById(R.id.iv_ok);
        final ImageView ivClose = dialog.findViewById(R.id.iv_close);

        final Spinner spFromAge = dialog.findViewById(R.id.sp_from_age);
        final Spinner spToAge = dialog.findViewById(R.id.sp_to_age);

        ivOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        spFromAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                spFromAge.setSelection(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spToAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                spToAge.setSelection(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    private void showHeightSelectionDialog(){

        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_height_selection);
        dialog.setCancelable(true);
        dialog.show();

        final ImageView ivOk = dialog.findViewById(R.id.iv_ok);
        final ImageView ivClose = dialog.findViewById(R.id.iv_close);

        final Spinner spFromAge = dialog.findViewById(R.id.sp_from_height);
        final Spinner spToAge = dialog.findViewById(R.id.sp_to_height);

        ivOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        spFromAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                spFromAge.setSelection(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spToAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                spToAge.setSelection(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void showCasteSelectionDialog(final String name){
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        View mDialogView = LayoutInflater.from(mContext).inflate(R.layout.dialog_caste_layout,
                null);

        TextView tvTitle = mDialogView.findViewById(R.id.tv_select_cast_tag);
        TextView tvClearAll = mDialogView.findViewById(R.id.tv_clear_all_tag);
        RecyclerView rvCaste = mDialogView.findViewById(R.id.rv_caste);

        final ArrayList<String> selectedItemsList = new ArrayList<>(0);
        final ArrayList<SelectionModel> adapterList = new ArrayList<>(0);

        switch (name){
            case "Caste":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_caste));
                adapterList.addAll(getCastList());
                break;

            case "Language":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_mother_toungue));
                adapterList.addAll(getLanguageList());
                break;
            case "Religion":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_religion));
                adapterList.addAll(getReligionList());
                break;
            case "City":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_city));
                adapterList.addAll(getCityIndiaList());
                break;
            case "State":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_state));
                adapterList.addAll(getStateIndiaList());
                break;
            case "Country":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_country));
                adapterList.addAll(getCountryList());
                break;
                default:
                    break;
        }

        final SelectionAdapter adapter = new SelectionAdapter(mContext, adapterList,
                new SelectionListener() {
                    @Override
                    public void onCheckStateChanged(boolean check, int positioin) {
                        switch (name){
                            case "Caste":
                                if(check){
                                    selectedItemsList.add(getCastList().get(positioin).getName());
                                }
                                else{
                                    selectedItemsList.remove(getCastList().get(positioin).getName());
                                }
                                break;

                            case "Language":
                                if(check){
                                    selectedItemsList.add(getLanguageList().get(positioin).getName());
                                }
                                else{
                                    selectedItemsList.remove(getLanguageList().get(positioin).getName());
                                }
                                break;
                            case "Religion":
                                if(check){
                                    selectedItemsList.add(getReligionList().get(positioin).getName());
                                }
                                else{
                                    selectedItemsList.remove(getReligionList().get(positioin).getName());
                                }
                                break;
                            case "City":
                                if(check){
                                    selectedItemsList.add(getCityIndiaList().get(positioin).getName());
                                }
                                else{
                                    selectedItemsList.remove(getCityIndiaList().get(positioin).getName());
                                }
                                break;
                            case "State":
                                if(check){
                                    selectedItemsList.add(getStateIndiaList().get(positioin).getName());
                                }
                                else{
                                    selectedItemsList.remove(getStateIndiaList().get(positioin).getName());
                                }
                                break;
                            case "Country":
                                if(check){
                                    selectedItemsList.add(getCountryList().get(positioin).getName());
                                }
                                else{
                                    selectedItemsList.remove(getCountryList().get(positioin).getName());
                                }
                                break;
                            default:
                                break;
                        }
                    }
                });


        tvClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (name){
                    case "Caste":
                        adapter.clearAllSelection(getCastList());
                        break;

                    case "Language":
                        adapter.clearAllSelection(getLanguageList());
                        break;
                    case "Religion":
                        adapter.clearAllSelection(getReligionList());
                        break;
                    case "City":
                        adapter.clearAllSelection(getCityIndiaList());
                        break;
                    case "State":
                        adapter.clearAllSelection(getStateIndiaList());
                        break;
                    case "Country":
                        adapter.clearAllSelection(getCountryList());
                        break;
                    default:
                        break;
                }

                adapter.notifyDataSetChanged();
            }
        });

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext,
                LinearLayoutManager.VERTICAL, false);
        rvCaste.setLayoutManager(layoutManager);

        rvCaste.setAdapter(adapter);
        builder.setView(mDialogView);
        builder.setCancelable(true);
        builder.setPositiveButton(mContext.getResources().getString(R.string.tag_ok),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

        builder.setNegativeButton(mContext.getResources().getString(R.string.tag_cancel),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(mContext.getResources()
                .getColor(R.color.line_divider));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(mContext.getResources()
                .getColor(R.color.colorPrimaryDark));
    }

    private ArrayList<SelectionModel> getCastList(){
        ArrayList<SelectionModel> list = new ArrayList<>(0);
        String[] array = mContext.getResources().getStringArray(R.array.array_cast);
        for(int i = 0; i< array.length; i++){
            SelectionModel model = new SelectionModel();
            model.setName(array[i]);
            model.setState(false);
            list.add(model);
        }
        return list;
    }

    private ArrayList<SelectionModel> getLanguageList(){
        ArrayList<SelectionModel> list =  new ArrayList<>(0);
        String[] languageArray = mContext.getResources().getStringArray(R.array.array_language);
        for(int i = 0; i< languageArray.length; i++){
            SelectionModel model = new SelectionModel();
            model.setName(languageArray[i]);
            model.setState(false);
            list.add(model);
        }
        return list;
    }

    private ArrayList<SelectionModel> getReligionList(){
        ArrayList<SelectionModel> list =  new ArrayList<>(0);
        String[] languageArray = mContext.getResources().getStringArray(R.array.array_religion);
        for(int i = 0; i< languageArray.length; i++){
            SelectionModel model = new SelectionModel();
            model.setName(languageArray[i]);
            model.setState(false);
            list.add(model);
        }
        return list;
    }

    private ArrayList<SelectionModel> getCountryList(){
        ArrayList<SelectionModel> list =  new ArrayList<>(0);
        String[] languageArray = mContext.getResources().getStringArray(R.array.array_country);
        for(int i = 0; i< languageArray.length; i++){
            SelectionModel model = new SelectionModel();
            model.setName(languageArray[i]);
            model.setState(false);
            list.add(model);
        }
        return list;
    }

    private ArrayList<SelectionModel> getStateIndiaList(){
        ArrayList<SelectionModel> list =  new ArrayList<>(0);
        String[] languageArray = mContext.getResources().getStringArray(R.array.array_state_india);
        for(int i = 0; i< languageArray.length; i++){
            SelectionModel model = new SelectionModel();
            model.setName(languageArray[i]);
            model.setState(false);
            list.add(model);
        }
        return list;
    }

    private ArrayList<SelectionModel> getCityIndiaList(){
        ArrayList<SelectionModel> list =  new ArrayList<>(0);
        String[] languageArray = mContext.getResources().getStringArray(R.array.array_city_list_india);
        for(int i = 0; i< languageArray.length; i++){
            SelectionModel model = new SelectionModel();
            model.setName(languageArray[i]);
            model.setState(false);
            list.add(model);
        }
        return list;
    }


    private void showAdvanceSearchOptions(final String name){
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        View mDialogView = LayoutInflater.from(mContext).inflate(R.layout.dialog_professional_preferences,
                null);

        TextView tvTitle = mDialogView.findViewById(R.id.tv_select_profession_tag);
        TextView tvEducation = mDialogView.findViewById(R.id.tv_education_tag);
        TextView tvOccupation = mDialogView.findViewById(R.id.tv_occupation_tag);
        TextView tvIndustry = mDialogView.findViewById(R.id.tv_industry_tag);
        TextView tvIncome = mDialogView.findViewById(R.id.tv_income_tag);

        switch (name){
            case "Profession":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_profession_details));
                tvEducation.setText(mContext.getResources().getString(R.string.tag_highest_education));
                tvOccupation.setText(mContext.getResources().getString(R.string.tag_occupation));
                tvIndustry.setText(mContext.getResources().getString(R.string.tag_industry));
                tvIncome.setText(mContext.getResources().getString(R.string.tag_income));
                break;

            case "Physical":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_physical_detials));
                tvEducation.setText(mContext.getResources().getString(R.string.tag_body_type));
                tvOccupation.setText(mContext.getResources().getString(R.string.tag_complexion));
                tvIndustry.setText(mContext.getResources().getString(R.string.tag_blood_group));
                tvIncome.setText(mContext.getResources().getString(R.string.tag_other));
                break;
            case "Lifestyle":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_lifestyle_details));
                tvEducation.setText(mContext.getResources().getString(R.string.tag_smoking));
                tvOccupation.setText(mContext.getResources().getString(R.string.tag_drinking));
                tvIndustry.setText(mContext.getResources().getString(R.string.tag_house_living_in));
                tvIncome.setText(mContext.getResources().getString(R.string.tag_children));
                break;
            case "Astrology":
                tvTitle.setText(mContext.getResources().getString(R.string.tag_astrology_details));
                tvEducation.setText(mContext.getResources().getString(R.string.tag_astro_name));
                tvOccupation.setText(mContext.getResources().getString(R.string.tag_luck_number));
                tvIndustry.setText(mContext.getResources().getString(R.string.tag_maglik));
                tvIncome.setText(mContext.getResources().getString(R.string.tag_other));
                break;
            default:
                break;
        }
        builder.setView(mDialogView);
        builder.setCancelable(true);
        builder.setPositiveButton(mContext.getResources().getString(R.string.tag_ok),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

        builder.setNegativeButton(mContext.getResources().getString(R.string.tag_cancel),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(mContext.getResources()
                .getColor(R.color.line_divider));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(mContext.getResources()
                .getColor(R.color.colorPrimaryDark));
    }

}
