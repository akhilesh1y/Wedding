package com.app.clmsoftwaresolution.bengaliwedding.model;

public class ExpandableModel {
    public String menuName;
    public boolean hasChildren;
    public boolean isGroup;

    public ExpandableModel(String menuName, boolean isGroup, boolean hasChildren) {

        this.menuName = menuName;
        this.isGroup = isGroup;
        this.hasChildren = hasChildren;
    }
}
