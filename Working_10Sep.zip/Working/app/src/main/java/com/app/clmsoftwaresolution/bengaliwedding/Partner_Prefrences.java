package com.app.clmsoftwaresolution.bengaliwedding;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

public class Partner_Prefrences extends AppCompatActivity {
TextView partner_pref_more_text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partner__prefrences);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        partner_pref_more_text=findViewById(R.id.partner_pref_more_text);
        partner_pref_more_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                partner_pref_more_text.setVisibility(View.GONE);

            }
        });

    }

}
