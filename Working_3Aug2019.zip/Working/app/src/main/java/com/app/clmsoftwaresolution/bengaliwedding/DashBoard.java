package com.app.clmsoftwaresolution.bengaliwedding;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Interaction;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Matches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.NotificationFragment;
import com.app.clmsoftwaresolution.bengaliwedding.othersProfile.OthersProfileActivity;
import com.app.clmsoftwaresolution.bengaliwedding.search.Search;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class DashBoard extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    /*    viewPager = (ViewPager) findViewById(R.id.mainactivity_viewpager);
        setupViewPager(viewPager);
        tabLayout = (TabLayout) findViewById(R.id.mainactivity_tabs);
        tabLayout.setupWithViewPager(viewPager)*/;

        mContext = this;
        initView();


    }


    private void initView(){
        CardView cardView1 = findViewById(R.id.card_view111);
        CardView cardView2 = findViewById(R.id.card_view12_);
        CardView cardView3 = findViewById(R.id.card_view123_);
        CardView cardView4 = findViewById(R.id.card_view12);

        CardView cardView5 = findViewById(R.id.card_view123);
        CardView cardView6 = findViewById(R.id.card_view14);
        CardView cardView7 = findViewById(R.id.card_view_me);
        CircleImageView iv1 = findViewById(R.id.profile_image1);
        CircleImageView iv2 = findViewById(R.id.profile_image2);
        CircleImageView iv3 = findViewById(R.id.profile_image3);

        cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        iv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        iv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        iv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new Matches(), "Matches");
//        adapter.addFragment(new Shortlisted(), "Recently View");
        adapter.addFragment(new Interaction(), "My Interaction");

        viewPager.setAdapter(adapter);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dash_board, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_notifications) {
            startActivity(new Intent(getApplicationContext(),NotificationFragment.class));
        }else if(id==R.id.action_profile){
            startActivity(new Intent(getApplicationContext(),User_Profile.class));
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_mypartnerpreferenceicon) {
            startActivity(new Intent(getApplicationContext(),Partner_Prefrences.class));

        } else if (id == R.id.nav_mymatches) {
            startActivity(new Intent(getApplicationContext(),MyMatches.class));
        } else if (id == R.id.nav_my_interaction) {
            startActivity(new Intent(this, My_intraction.class));
        }else if(id==R.id.nav_accountsetting){
            startActivity(new Intent(getApplicationContext(),AccountSetting.class));
        }else if(id==R.id.nav_search){
            startActivity(new Intent(getApplicationContext(),Search.class));
        }
        else if(id==R.id.nav_notificatios){
            startActivity(new Intent(getApplicationContext(), NotificationFragment.class));
        }
        else if(id == R.id.nav_about_us){
            startActivity(new Intent(getApplicationContext(), AboutUsActivity.class));
        }
        else if(id == R.id.nav_help){
            startActivity(new Intent(getApplicationContext(), HelpActivity.class));
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }


    }

}
