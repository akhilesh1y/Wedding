package com.app.clmsoftwaresolution.bengaliwedding.model;

import java.io.Serializable;

public class SelectionModel implements Serializable {
    private String name;
    private boolean state;


    public String getName() {
        return name;
    }

    public boolean getState() {
        return state;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setState(boolean state) {
        this.state = state;
    }
}
