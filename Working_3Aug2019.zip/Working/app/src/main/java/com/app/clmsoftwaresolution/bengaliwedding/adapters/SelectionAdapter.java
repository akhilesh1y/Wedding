package com.app.clmsoftwaresolution.bengaliwedding.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.clmsoftwaresolution.bengaliwedding.R;
import com.app.clmsoftwaresolution.bengaliwedding.holders.CustomHolder;
import com.app.clmsoftwaresolution.bengaliwedding.listeners.SelectionListener;
import com.app.clmsoftwaresolution.bengaliwedding.model.SelectionModel;

import java.util.ArrayList;

public class SelectionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final String TAG = SelectionAdapter.class.getName();
    private Context mContext;
    private ArrayList<SelectionModel> selectionModels;
    private View mView;
    private SelectionListener listener;


    private SelectionAdapter(){}

    public SelectionAdapter(Context context, ArrayList<SelectionModel> list, SelectionListener callback){
        this.mContext = context;
        this.selectionModels = list;
        this.listener = callback;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        mView = LayoutInflater.from(mContext).inflate(R.layout.item_list_dialog_caste, viewGroup,
                    false);
            return new CustomHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        ((CustomHolder)viewHolder).bindView(selectionModels.get(position), listener, position);
    }

    @Override
    public int getItemCount() {
        if (null != selectionModels)
            return selectionModels.size();

        return 0;
    }

    public void clearAllSelection(ArrayList<SelectionModel> list){
        this.selectionModels.clear();
        this.selectionModels = list;
    }

}
