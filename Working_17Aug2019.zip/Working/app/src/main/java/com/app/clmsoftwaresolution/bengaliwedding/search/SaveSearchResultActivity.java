package com.app.clmsoftwaresolution.bengaliwedding.search;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.PopupMenu;

import com.app.clmsoftwaresolution.bengaliwedding.R;

public class SaveSearchResultActivity extends AppCompatActivity {

    private static final String TAG  = SaveSearchResultActivity.class.getName();
    private Context mContext;

    private Toolbar toolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_search_profile);
        toolbar = findViewById(R.id.toolbar);

        init();
    }

    private void init(){
        mContext = this;
        initView();
    }

    private void initView(){

        ImageView iv_Options = findViewById(R.id.iv_option_menu);

        PopupMenu popup = new PopupMenu(mContext, iv_Options);

        popup.getMenuInflater().inflate(R.menu.menu_saved_result, popup.getMenu());

        //registering popup with OnMenuItemClickListener
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                return true;
            }
        });

        popup.show();//showing popup menu


    }
}
