package com.app.clmsoftwaresolution.bengaliwedding.othersProfile;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.app.clmsoftwaresolution.bengaliwedding.R;

public class OthersProfileActivity extends AppCompatActivity {

    private final String TAG = OthersProfileActivity.class.getName();
    private Context mContext;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v(TAG, "OnCreate");
        setContentView(R.layout.activity_others_profile);

        init();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

    private void init(){

    }
}
