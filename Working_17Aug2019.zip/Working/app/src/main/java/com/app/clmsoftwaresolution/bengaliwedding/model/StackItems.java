package com.app.clmsoftwaresolution.bengaliwedding.model;

public class StackItems {
    Integer image;

    public StackItems(String name, Integer image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }
}
