package com.app.clmsoftwaresolution.bengaliwedding;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.app.clmsoftwaresolution.bengaliwedding.Fragment.AcceptedMeFragment;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Astromatches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.BockedFragment;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.BockedMeFragment;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.IAcceptedFragment;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Lastvisitor;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Matches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.MyDesierMatches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Partnerlooking_Matches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Received;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.RecentVisitor;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.SentItemsFragment;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Shortlisted;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Verifymatches;
import com.app.clmsoftwaresolution.bengaliwedding.adapters.InteractionViewPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class My_intraction extends AppCompatActivity {

    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_intraction);

        iniViews();
        setToolbar();
        setViewPager();

    }

    private void iniViews() {
        mToolbar = findViewById(R.id.toolbar);
        mViewPager = findViewById(R.id.interaction_activity_viewpager);
        mTabLayout = findViewById(R.id.interaction_activity_tabs);



    }

    private void setToolbar() {
        setSupportActionBar(mToolbar);
    }

    private void setViewPager() {
        setupViewPager();
        mTabLayout.setupWithViewPager(mViewPager);
    }

    private void setupViewPager() {
        InteractionViewPagerAdapter adapter = new InteractionViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new Received(), "Received");
        adapter.addFragment(new IAcceptedFragment(), "I Accepted");
        adapter.addFragment(new AcceptedMeFragment(), "Accepted Me");
        adapter.addFragment(new BockedFragment(), "I Declined/Blocked");
        adapter.addFragment(new BockedMeFragment(), "Declined/Blocked Me");
        adapter.addFragment(new SentItemsFragment(), "Sent Items");
        mViewPager.setAdapter(adapter);
    }
}
