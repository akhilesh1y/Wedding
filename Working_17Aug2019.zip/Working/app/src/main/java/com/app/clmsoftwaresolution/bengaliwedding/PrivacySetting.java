package com.app.clmsoftwaresolution.bengaliwedding;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class PrivacySetting extends AppCompatActivity {

    private static final String TAG  = PrivacySetting.class.getName();
    private Context mContext;
    private RadioGroup rgContactDeails;
    private RadioButton rbViewNoOne;
    private RadioButton rbViewByAll;
    private RadioButton rbWhoRequested;
    private RadioButton rbProfileMyMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_setting);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ui();
    }

    private void ui(){
        initContext();
        initViews();
        clickListeners();
    }

    private void initContext(){
        mContext = this;
    }

    private void initViews(){
        rgContactDeails = findViewById(R.id.radioGroup_who_see_details);
        rbViewNoOne = findViewById(R.id.radioButton_view_no_one);
        rbViewByAll = findViewById(R.id.radioButton_view_by_all_visitors);
        rbWhoRequested = findViewById(R.id.radioButton_whose_request);
        rbProfileMyMe = findViewById(R.id.radioButton_profile_match_as_per_me);
    }

    private void clickListeners(){
        rbViewNoOne.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    rbViewByAll.setEnabled(false);
                    rbWhoRequested.setEnabled(false);
                    rbProfileMyMe.setEnabled(false);

                    rbViewByAll.setChecked(false);
                    rbWhoRequested.setChecked(false);
                    rbProfileMyMe.setChecked(false);

                }
            }
        });

        rbViewByAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    rbWhoRequested.setEnabled(true);
                    rbProfileMyMe.setEnabled(true);

                    rbWhoRequested.setChecked(true);
                    rbProfileMyMe.setChecked(true);
                }
            }
        });

    }

}
