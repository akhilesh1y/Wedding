package com.app.clmsoftwaresolution.bengaliwedding.listeners;

public interface SelectionListener {
    void onCheckStateChanged(boolean check, int position);
}
