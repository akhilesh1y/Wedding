package com.app.clmsoftwaresolution.bengaliwedding.Fragment;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.app.clmsoftwaresolution.bengaliwedding.R;

public class AcceptedMeFragment extends Fragment {

    private View mView;
    private Context mContext;
    private ImageView ivOptions;
    private ImageView ivFilter;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        if(null == mView)
            mView = inflater.inflate(R.layout.fragment_me_accepted, container, false);

        initViews();
        return mView;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // ui();
    }

    private void initViews() {
        ivOptions = mView.findViewById(R.id.tv_options);
        ivFilter = mView.findViewById(R.id.iv_filter);

        clickListeners();
    }

    private void clickListeners() {
        ivFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filterDialog();
            }
        });

        ivOptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                optionDialog(view);
            }
        });
    }

    private void optionDialog(View view) {
        final PopupMenu menu = new PopupMenu(mContext, view);
        menu.getMenuInflater().inflate(R.menu.received_menu, menu.getMenu());

        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {

                    case R.id.action_add_to_shortcut:
                        menu.dismiss();
                        return true;
                    case R.id.action_block_this_profile:
                        menu.dismiss();
                        return true;
                    case R.id.action_report_as_fake:
                        menu.dismiss();
                        return true;
                    case R.id.action_share_this_profile:
                        menu.dismiss();
                        return true;
                    case R.id.action_do_not_show_again:
                        menu.dismiss();
                        return true;
                    default:
                        return false;
                }
            }
        });

        menu.show();
    }

    private void filterDialog() {

        Dialog dialog = new Dialog(mContext);
        dialog.setContentView(R.layout.dialog_received_filter);
        dialog.setCancelable(true);
        LinearLayout layout  = dialog.findViewById(R.id.ll_interaction_status);
        layout.setVisibility(View.GONE);
        dialog.findViewById(R.id.tv_interaction).setVisibility(View.GONE);
        dialog.show();

    }
}
