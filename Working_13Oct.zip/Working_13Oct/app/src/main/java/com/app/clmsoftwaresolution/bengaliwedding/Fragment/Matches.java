package com.app.clmsoftwaresolution.bengaliwedding.Fragment;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import com.app.clmsoftwaresolution.bengaliwedding.MymatchRefine;
import com.app.clmsoftwaresolution.bengaliwedding.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Matches extends Fragment {
    Spinner spinner_search;
    RecyclerView recyclerView;
    RelativeLayout mymatch_refine;
    MatchesRecycleviewAdapter matchesRecycleviewAdapter;
    RecyclerView.LayoutManager recyclerViewLayoutManager;
    Context context;
    String[] search_data={"All","Patner Prefrence","Partner looking for me"};
    Integer[] image={
            R.drawable.pro_logo,
            R.drawable.pro_logo,
            R.drawable.pro_logo,
            R.drawable.pro_logo,
            R.drawable.pro_logo,
            R.drawable.pro_logo,
            R.drawable.pro_logo
    };

    public Matches() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
     View vv=inflater.inflate(R.layout.fragment_matches, container, false);
        context=getContext();

      /*  spinner_search = (Spinner)vv.findViewById(R.id.material_match_serch);
        ArrayAdapter<String> triptype_dataAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, search_data);
        triptype_dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_search.setAdapter(triptype_dataAdapter);
*/

        mymatch_refine=vv.findViewById(R.id.mymatch_refine);
        mymatch_refine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),MymatchRefine.class));
            }
        });
        matchesRecycleviewAdapter = new MatchesRecycleviewAdapter(image,context);
        recyclerView=(RecyclerView)vv.findViewById(R.id.matches_recycleview);
        recyclerView.setHasFixedSize(true);
        recyclerViewLayoutManager = new GridLayoutManager(context,1);
        recyclerView.setLayoutManager(recyclerViewLayoutManager);
        recyclerView.setAdapter(matchesRecycleviewAdapter);


        return vv;
    }

    private class MatchesRecycleviewAdapter extends RecyclerView.Adapter<MatchesRecycleviewAdapter.ViewHolder> {
        Integer[] image;
        Context context;
        public MatchesRecycleviewAdapter(Integer[] image, Context context) {
            this.context=context;
            this.image=image;
        }

        @Override
        public MatchesRecycleviewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        /*View view1 = LayoutInflater.from(context).inflate(R.layout.matches_item, parent, false);
     ViewHolder viewHolder=new ViewHolder(view1);
        return viewHolder;*/
            View view = LayoutInflater.from(context).inflate(R.layout.matches_item,parent,false);
            ViewHolder viewHolder1 = new ViewHolder(view);
            return viewHolder1;
        }

        @Override
        public void onBindViewHolder(MatchesRecycleviewAdapter.ViewHolder holder, int position) {
           // holder.matches_imageview.setImageResource(image[position]);
        }

        @Override
        public int getItemCount() {
            return image.length;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView matches_imageview;

            public ViewHolder(View itemView) {
                super(itemView);
                //matches_imageview=(ImageView)itemView.findViewById(R.id.matches_image);
            }


        }
    }
}
