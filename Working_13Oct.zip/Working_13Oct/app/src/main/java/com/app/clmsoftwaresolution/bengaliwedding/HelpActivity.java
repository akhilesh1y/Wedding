package com.app.clmsoftwaresolution.bengaliwedding;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class HelpActivity extends AppCompatActivity {

    private RelativeLayout mRlNormalHelp;
    private RelativeLayout mRlCustomerHelp;
    private RelativeLayout mRlFeedback;
    private LinearLayout mLlNormal;
    private LinearLayout mLlCustomer;
    private LinearLayout mLlFeedback;

    private boolean[] status = new boolean[]{false, false, false};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        initViews();
        viewClickListeners();
    }

    private void initViews(){

        mRlNormalHelp = findViewById(R.id.rl_normal_help);
        mLlNormal = findViewById(R.id.ll_normal_help);
        mRlCustomerHelp = findViewById(R.id.rl_contact_help);
        mLlCustomer = findViewById(R.id.ll_customer_care_help);
        mRlFeedback = findViewById(R.id.rl_feedback_help);
        mLlFeedback = findViewById(R.id.ll_feedback_help);

    }

    private void viewClickListeners(){
        mRlNormalHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (status[0]) {
                    status[0] = false;
                    mLlNormal.setVisibility(View.GONE);
                }
                else{
                    status[0] = true;
                    mLlNormal.setVisibility(View.VISIBLE);
                }
            }
        });

        mRlCustomerHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (status[1]) {
                    status[1] = false;
                    mLlCustomer.setVisibility(View.GONE);
                }
                else{
                    status[1] = true;
                    mLlCustomer.setVisibility(View.VISIBLE);
                }

            }
        });

        mRlFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (status[2]) {
                    status[2] = false;
                    mLlFeedback.setVisibility(View.GONE);
                }
                else{
                    status[2] = true;
                    mLlFeedback.setVisibility(View.VISIBLE);
                }

            }
        });
    }
}
