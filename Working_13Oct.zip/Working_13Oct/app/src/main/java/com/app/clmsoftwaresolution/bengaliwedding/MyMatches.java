package com.app.clmsoftwaresolution.bengaliwedding;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Astromatches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Interaction;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Lastvisitor;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Matches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.MyDesierMatches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Partnerlooking_Matches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.RecentVisitor;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Shortlisted;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Verifymatches;

import java.util.ArrayList;
import java.util.List;

public class MyMatches extends AppCompatActivity {
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_matches);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        viewPager = (ViewPager) findViewById(R.id.mainactivity_viewpager);
        setupViewPager(viewPager);
        tabLayout = (TabLayout) findViewById(R.id.mainactivity_tabs);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new Matches(), "Newly join in Mymatches");
        adapter.addFragment(new MyDesierMatches(), "My Desire Match");
        adapter.addFragment(new Partnerlooking_Matches(), "Partner looking for me");
        adapter.addFragment(new Shortlisted(), "Shortlisted Profiles");
        adapter.addFragment(new Astromatches(), "Astro Match");
        adapter.addFragment(new Verifymatches(), "Verified Match");
        adapter.addFragment(new RecentVisitor(), "Recent Visitor");
        adapter.addFragment(new Lastvisitor(), "Last Visitor");
        viewPager.setAdapter(adapter);
    }

    private class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }


    }
}
