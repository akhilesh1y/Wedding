package com.app.clmsoftwaresolution.bengaliwedding;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.RelativeLayout;

public class AccountSetting extends AppCompatActivity implements View.OnClickListener {
RelativeLayout setting_myaccount,setting_privacysetting,setting_resetpassword,setting_deactivateaccount,setting_myalert,setting_logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_setting);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setting_myaccount=findViewById(R.id.setting_myaccount);
        setting_privacysetting=findViewById(R.id.setting_privacysetting);
        setting_resetpassword=findViewById(R.id.setting_resetpassword);
        setting_deactivateaccount=findViewById(R.id.setting_deactivateaccount);
        setting_myalert=findViewById(R.id.setting_myalert);
        setting_logout=findViewById(R.id.setting_myalert);

        setting_myaccount.setOnClickListener(this);
        setting_privacysetting.setOnClickListener(this);
        setting_resetpassword.setOnClickListener(this);
        setting_deactivateaccount.setOnClickListener(this);
        setting_myalert.setOnClickListener(this);
        setting_logout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.setting_myaccount:
                startActivity(new Intent(getApplicationContext(),User_Profile.class));
                break;
            case R.id.setting_privacysetting:
                startActivity(new Intent(getApplicationContext(),PrivacySetting.class));
                break;
            case R.id.setting_resetpassword:
                startActivity(new Intent(getApplicationContext(),Resetpassword.class));
                break;
            case R.id.setting_deactivateaccount:
                startActivity(new Intent(getApplicationContext(),Deactivatemyaccount.class));
                break;
            case R.id.setting_myalert:
                startActivity(new Intent(getApplicationContext(),MyAlert.class));
                break;
            case R.id.setting_logout:
                break;
        }
    }
}
