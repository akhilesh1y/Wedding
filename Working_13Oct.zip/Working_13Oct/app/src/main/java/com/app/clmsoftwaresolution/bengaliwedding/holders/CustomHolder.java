package com.app.clmsoftwaresolution.bengaliwedding.holders;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.app.clmsoftwaresolution.bengaliwedding.R;
import com.app.clmsoftwaresolution.bengaliwedding.listeners.SelectionListener;
import com.app.clmsoftwaresolution.bengaliwedding.model.SelectionModel;

public class CustomHolder extends RecyclerView.ViewHolder {

    private static final String TAG = CustomHolder.class.getName();
    private TextView tvName;
    private CheckBox cbState;
    public CustomHolder(@NonNull View itemView) {
        super(itemView);
        tvName = itemView.findViewById(R.id.tv_caste);
        cbState = itemView.findViewById(R.id.cb_item_selection);
    }

    public void bindView(@NonNull final SelectionModel model, final SelectionListener listener, final int position) {
        if (null == model)
            return;

        tvName.setText(model.getName());
        cbState.setChecked(model.getState());
        cbState.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                model.setState(b);
                listener.onCheckStateChanged(b, position);
            }
        });
    }
}
