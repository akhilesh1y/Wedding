package com.app.clmsoftwaresolution.bengaliwedding;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.StackView;

import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Interaction;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.Matches;
import com.app.clmsoftwaresolution.bengaliwedding.Fragment.NotificationFragment;
import com.app.clmsoftwaresolution.bengaliwedding.adapters.ExpandableListAdapter;
import com.app.clmsoftwaresolution.bengaliwedding.adapters.StackAdapter;
import com.app.clmsoftwaresolution.bengaliwedding.model.ExpandableModel;
import com.app.clmsoftwaresolution.bengaliwedding.model.StackItems;
import com.app.clmsoftwaresolution.bengaliwedding.othersProfile.OthersProfileActivity;
import com.app.clmsoftwaresolution.bengaliwedding.search.SaveSearchResultActivity;
import com.app.clmsoftwaresolution.bengaliwedding.search.Search;
import com.github.anastr.speedviewlib.SpeedView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class DashBoard extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Context mContext;

    private static StackView mStackView;
    private static ArrayList<StackItems> list;

    private static final Integer[] icons = {R.drawable.ic_profile_medium, R.drawable.ic_profile_medium,
            R.drawable.ic_profile_medium, R.drawable.ic_profile_medium, R.drawable.ic_profile_medium};

    ExpandableListAdapter expandableListAdapter;
    ExpandableListView expandableListView;
    List<ExpandableModel> headerList = new ArrayList<>();
    HashMap<ExpandableModel, List<ExpandableModel>> childList = new HashMap<>();
    private DrawerLayout drawer;
    private int lastExpandedPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    /*    viewPager = (ViewPager) findViewById(R.id.mainactivity_viewpager);
        setupViewPager(viewPager);
        tabLayout = (TabLayout) findViewById(R.id.mainactivity_tabs);
        tabLayout.setupWithViewPager(viewPager)*/;

        mContext = this;
        initView();


    }


    private void initView(){
        CardView cardView1 = findViewById(R.id.card_view111);
        CardView cardView2 = findViewById(R.id.card_view12_);
        CardView cardView3 = findViewById(R.id.card_view123_);
        CardView cardView4 = findViewById(R.id.card_view12);

        CardView cardView5 = findViewById(R.id.card_view123);
        CardView cardView6 = findViewById(R.id.card_view14);
        CardView cardView7 = findViewById(R.id.card_view_me);
        CircleImageView iv1 = findViewById(R.id.profile_image1);
        CircleImageView iv2 = findViewById(R.id.profile_image2);
        CircleImageView iv3 = findViewById(R.id.profile_image3);

        cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        iv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        cardView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        iv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        iv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, OthersProfileActivity.class));
            }
        });

        final ImageView ivOptionDesire = findViewById(R.id.iv_profile_medium_option);
        final ImageView ivOptionDesire1 = findViewById(R.id.iv_profile_medium_option1);
        final ImageView ivOptionWaiting = findViewById(R.id.iv_profile_waiting_response);
        final ImageView ivOptionWaiting1 = findViewById(R.id.iv_profile_waiting_response1);


        ivOptionDesire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDesirePopUpMenu(ivOptionDesire);
            }
        });

        ivOptionDesire1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDesirePopUpMenu(ivOptionDesire1);
            }
        });

        ivOptionWaiting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDesirePopUpMenu(ivOptionWaiting);
            }
        });

        ivOptionWaiting1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDesirePopUpMenu(ivOptionWaiting1);
            }
        });

        mStackView = (StackView) findViewById(R.id.sv_slider);
        list = new ArrayList();

        addItemToAdapter();

        expandableListView = findViewById(R.id.expandableListView);
        prepareMenuData();
        populateExpandableList();
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                if (lastExpandedPosition != -1
                        && groupPosition != lastExpandedPosition) {
                    expandableListView.collapseGroup(lastExpandedPosition);
                }
                lastExpandedPosition = groupPosition;
            }
        });

        /*SpeedView speedView = findViewById(R.id.speedView);
        speedView.speedTo(50);
        speedView.setSpeedTextColor(getResources().getColor(android.R.color.transparent));*/
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new Matches(), "Matches");
//        adapter.addFragment(new Shortlisted(), "Recently View");
        adapter.addFragment(new Interaction(), "My Interaction");

        viewPager.setAdapter(adapter);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dash_board, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_notifications) {
            startActivity(new Intent(getApplicationContext(),NotificationFragment.class));
        }else if(id==R.id.action_profile){
            startActivity(new Intent(getApplicationContext(),User_Profile.class));
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_mypartnerpreferenceicon) {
            startActivity(new Intent(getApplicationContext(),Partner_Prefrences.class));

        } else if (id == R.id.nav_mymatches) {
            startActivity(new Intent(getApplicationContext(),MyMatches.class));
        } else if (id == R.id.nav_my_interaction) {
            startActivity(new Intent(this, My_intraction.class));
        }else if(id==R.id.nav_accountsetting){
            startActivity(new Intent(getApplicationContext(),AccountSetting.class));
        }else if(id==R.id.nav_search){
            startActivity(new Intent(getApplicationContext(),Search.class));
        }
        else if(id==R.id.nav_notificatios){
            startActivity(new Intent(getApplicationContext(), NotificationFragment.class));
        }
        else if(id == R.id.nav_about_us){
            startActivity(new Intent(getApplicationContext(), AboutUsActivity.class));
        }
        else if(id == R.id.nav_help){
            startActivity(new Intent(getApplicationContext(), HelpActivity.class));
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    private void showDesirePopUpMenu(ImageView imageView){
        //Creating the instance of PopupMenu
        PopupMenu popup = new PopupMenu(mContext, imageView);
        //Inflating the Popup using xml file
        popup.getMenuInflater().inflate(R.menu.desire_menu, popup.getMenu());

        //registering popup with OnMenuItemClickListener
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                return true;
            }
        });

        popup.show();//showing popup menu
    }

    private void addItemToAdapter(){
        for (int i = 0; i < icons.length; i++) {
            list.add(new StackItems("Item " + i, icons[i]));
        }
        StackAdapter adapter = new StackAdapter(mContext, list);
        mStackView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void prepareMenuData() {

        ExpandableModel menuModel = new ExpandableModel("Home", true, true);
        //Menu of Android Tutorial. No sub menus
        headerList.add(menuModel);
        List<ExpandableModel> childModelsList = new ArrayList<>();
        ExpandableModel childModel = new ExpandableModel("My Profile", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Improve My Trust Rate", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Partner Preferences", false, false);
        childModelsList.add(childModel);

        if (menuModel.hasChildren) {
            childList.put(menuModel, childModelsList);
        }

        menuModel = new ExpandableModel("My Match", true, true);
        headerList.add(menuModel);

        childModelsList = new ArrayList<>();
        childModel = new ExpandableModel("Newly Joined", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("My Desired Match", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Partner Looking For", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Mutual Matches", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Astrology Matches", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Suggested Matches", false, false);
        childModelsList.add(childModel);


        if (menuModel.hasChildren) {
            Log.d("API123","here");
            childList.put(menuModel, childModelsList);
        }

        childModelsList = new ArrayList<>();
        menuModel = new ExpandableModel("My Interaction", true, true); //Menu of Python Tutorials
        headerList.add(menuModel);

        childModel = new ExpandableModel("Received", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Accepted", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Declined or Blocked", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Sent Item", false, false);
        childModelsList.add(childModel);

        if (menuModel.hasChildren) {
            childList.put(menuModel, childModelsList);
        }

        menuModel = new ExpandableModel("Saved search Profile", true, false);
        headerList.add(menuModel);

        if (!menuModel.hasChildren) {
            childList.put(menuModel, null);
        }

        childModelsList = new ArrayList<>();
        menuModel = new ExpandableModel("More Options", true, true); //Menu of Python Tutorials
        headerList.add(menuModel);

        childModel = new ExpandableModel("Shortlisted Profile", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Recent Visitor", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Verified Members", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Previous View Profiles", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Delete Profile", false, false);
        childModelsList.add(childModel);

        if (menuModel.hasChildren) {
            childList.put(menuModel, childModelsList);
        }

        childModelsList = new ArrayList<>();
        menuModel = new ExpandableModel("Account Setting", true, true); //Menu of Python Tutorials
        headerList.add(menuModel);

        childModel = new ExpandableModel("Privacy Setting", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Reset Password", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Deactivate Account", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("My Alert", false, false);
        childModelsList.add(childModel);

        childModel = new ExpandableModel("Logout", false, false);
        childModelsList.add(childModel);

        if (menuModel.hasChildren) {
            childList.put(menuModel, childModelsList);
        }

        menuModel = new ExpandableModel("About Us", true, false);
        headerList.add(menuModel);

        if (!menuModel.hasChildren) {
            childList.put(menuModel, null);
        }

        menuModel = new ExpandableModel("Help & Support", true, false);
        headerList.add(menuModel);

        if (!menuModel.hasChildren) {
            childList.put(menuModel, null);
        }

        menuModel = new ExpandableModel("Logout", true, false);
        headerList.add(menuModel);

        if (!menuModel.hasChildren) {
            childList.put(menuModel, null);
        }


    }

    private void populateExpandableList() {

        expandableListAdapter = new ExpandableListAdapter(this, headerList, childList);
        expandableListView.setAdapter(expandableListAdapter);

        expandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {

                if (headerList.get(groupPosition).isGroup) {
                    if (!headerList.get(groupPosition).hasChildren) {

                        switch (groupPosition){
                            case 3:
                                mContext.startActivity(new Intent(mContext, SaveSearchResultActivity.class));
                                break;
                            case 6:
                                mContext.startActivity(new Intent(mContext, AboutUsActivity.class));
                                break;
                            case 7:
                                mContext.startActivity(new Intent(mContext, HelpActivity.class));
                                break;
                            case 8:
                                Intent intent =new Intent(mContext, Login.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                mContext.startActivity(intent);
                                finish();
                                break;
                                default:
                                    break;
                        }

                        // TODO Perform non expandable view click action
                        onBackPressed();
                    }
                }

                return false;
            }
        });

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

                if (childList.get(headerList.get(groupPosition)) != null) {
                    ExpandableModel model = childList.get(headerList.get(groupPosition)).get(childPosition);

                    switch (groupPosition) {
                        case 0:
                            switch (childPosition){
                                case 0:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(0);
                                    mContext.startActivity(new Intent(mContext, User_Profile.class));
                                    break;
                                case 1:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(0);
                                    break;
                                case 2:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(0);
                                    mContext.startActivity(new Intent(mContext,Partner_Prefrences.class));
                                    break;
                                    default:
                                        break;
                            }
                            break;
                        case 1:
                            switch (childPosition){
                                case 0:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(1);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    break;
                                case 1:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(1);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    break;
                                case 2:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(1);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    break;
                                case 3:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(1);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    break;
                                case 4:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(1);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    break;
                                case 5:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(1);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    break;
                                    default:
                                        break;
                            }
                            break;
                        case 2:
                            switch (childPosition){
                                case 0:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(2);
                                    mContext.startActivity(new Intent(mContext, My_intraction.class));
                                    break;
                                case 1:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(2);
                                    mContext.startActivity(new Intent(mContext, My_intraction.class));
                                    break;
                                case 2:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(2);
                                    mContext.startActivity(new Intent(mContext, My_intraction.class));
                                    break;
                                case 3:
                                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                                        drawer.closeDrawer(GravityCompat.START);
                                    }
                                    expandableListView.collapseGroup(2);
                                    mContext.startActivity(new Intent(mContext, My_intraction.class));
                                    break;
                                    default:
                                        break;
                            }
                            break;
                        case 4:
                            switch (childPosition){
                                case 0:
                                    expandableListView.collapseGroup(4);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    onBackPressed();
                                    break;
                                case 1:
                                    expandableListView.collapseGroup(4);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    onBackPressed();
                                    break;
                                case 2:
                                    expandableListView.collapseGroup(4);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    onBackPressed();
                                    break;
                                case 3:
                                    expandableListView.collapseGroup(4);
                                    mContext.startActivity(new Intent(mContext, MyMatches.class));
                                    onBackPressed();
                                    break;
                                case 4:
                                    expandableListView.collapseGroup(4);
                                    mContext.startActivity(new Intent(mContext, Deactivatemyaccount.class));
                                    onBackPressed();
                                    break;
                                    default:
                                        break;
                            }
                            break;
                        case 5:
                            switch (childPosition){
                                case 0:
                                    onBackPressed();
                                    expandableListView.collapseGroup(5);
                                    mContext.startActivity(new Intent(mContext, PrivacySetting.class));
                                    break;
                                case 1:
                                    onBackPressed();
                                    expandableListView.collapseGroup(5);
                                    mContext.startActivity(new Intent(mContext, Resetpassword.class));
                                    break;
                                case 2:
                                    onBackPressed();
                                    expandableListView.collapseGroup(5);
                                    mContext.startActivity(new Intent(mContext, Deactivatemyaccount.class));
                                    break;
                                case 3:
                                    onBackPressed();
                                    expandableListView.collapseGroup(5);
                                    mContext.startActivity(new Intent(mContext, MyAlert.class));
                                    break;
                                case 4:
                                    onBackPressed();
                                    expandableListView.collapseGroup(5);
                                    Intent intent =new Intent(mContext, Login.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    mContext.startActivity(intent);
                                    finish();
                                    break;
                                default:
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                }

                return false;
            }
        });
    }

}
