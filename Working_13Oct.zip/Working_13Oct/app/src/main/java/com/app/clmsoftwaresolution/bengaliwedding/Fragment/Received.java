package com.app.clmsoftwaresolution.bengaliwedding.Fragment;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;

import com.app.clmsoftwaresolution.bengaliwedding.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Received extends Fragment {
    private View mView;
    private Context mContext;
    private ImageView ivOptions;
    private ImageView ivFilter;


    public Received() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (null == mView)
            mView = inflater.inflate(R.layout.fragment_received, container, false);
        initViews();
        return mView;
    }

    private void initViews() {
        ivOptions = mView.findViewById(R.id.tv_options);
        ivFilter = mView.findViewById(R.id.iv_filter);

        clickListeners();
    }

    private void clickListeners() {
        ivFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filterDialog();
            }
        });

        ivOptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                optionDialog(view);
            }
        });
    }

    private void optionDialog(View view) {
        final PopupMenu menu = new PopupMenu(mContext, view);
        menu.getMenuInflater().inflate(R.menu.received_menu, menu.getMenu());

        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {

                    case R.id.action_add_to_shortcut:
                        menu.dismiss();
                        return true;
                    case R.id.action_block_this_profile:
                        menu.dismiss();
                        return true;
                    case R.id.action_report_as_fake:
                        menu.dismiss();
                        return true;
                    case R.id.action_share_this_profile:
                        menu.dismiss();
                        return true;
                    case R.id.action_do_not_show_again:
                        menu.dismiss();
                        return true;
                    default:
                        return false;
                }
            }
        });

        menu.show();
    }

    private void filterDialog() {

        Dialog dialog = new Dialog(mContext);
        dialog.setContentView(R.layout.dialog_received_filter);
        dialog.setCancelable(true);
        dialog.show();

    }

}
